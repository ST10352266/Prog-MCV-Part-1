﻿namespace PROG_PART1_MCV.Models
{
    public class LecturerClaim
    {
        public int ClaimId { get; set; }
        public string LecturerName { get; set; }
        public string LecturerSurname { get; set; }
        public int EmployeeNumber { get; set; }
        public string ContactDetails { get; set; }

        public List<Module> Modules { get; set; } = new List<Module>();

        public string Status { get; set; } = "Pending...";
    }

    public class Module
    {
        public string ModuleName { get; set; }
        public string Programme { get; set; }
        public int NumberOfHours { get; set; }
        public decimal HourlyRate { get; set; }
    }

}
