﻿namespace PROG_PART1_MCV.Controllers;
using Microsoft.AspNetCore.Mvc;
using PROG_PART1_MCV.Models;
using PROG_PART1_MCV.Models;

public class ControllerClaim : Controller
{
    public static List<LecturerClaim> Claims = new List<LecturerClaim>();

    [HttpGet]
    public IActionResult SubmitClaim()
    {
        return View(new LecturerClaim());
    }

    [HttpPost]
    public IActionResult SubmitClaim(LecturerClaim claim)
    {

        claim.ClaimId = Claims.Count + 1;
        Claims.Add(claim);
        return RedirectToAction("ClaimSubmitted");
    }

    public IActionResult ClaimSubmitted()
    {
        return View();
    }
}

