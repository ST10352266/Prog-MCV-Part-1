﻿namespace PROG_PART1_MCV.Controllers;
using Microsoft.AspNetCore.Mvc;
using PROG_PART1_MCV.Models;

public class ApprovalController : Controller
{
    public IActionResult ViewClaims()
    {
       
        return View(ControllerClaim.Claims);
    }

    public IActionResult Approve(int id)
    {
        var claim = ControllerClaim.Claims.FirstOrDefault(c => c.ClaimId == id);
        if (claim != null)
        {
            claim.Status = "Approved";
        }
        return RedirectToAction("ViewClaims");
    }

    public IActionResult Reject(int id)
    {
        var claim = ControllerClaim.Claims.FirstOrDefault(c => c.ClaimId == id);
        if (claim != null)
        {
            claim.Status = "Rejected";
        }
        return RedirectToAction("ViewClaims");
    }
}

